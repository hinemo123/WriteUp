# Baby Developer

* http://(IP):8888/: Mobile Viewer that is running on stypr's personal IP.

* ssh://(IP):2222/: stypr's ssh

## Install

```
docker-compose build
```

### Run

```
docker-compose up -d
```
